param(
    [string]$OpenSCAD = "C:\Program Files\OpenSCAD\openscad.com",
    [string]$OutputDir = ""
)

$ErrorActionPreference = "Stop"
$source = Join-Path $PSScriptRoot "hexapode_chassis_ventuno_q_light.scad"
if (-not $OutputDir) {
    $OutputDir = Join-Path (Split-Path $PSScriptRoot -Parent | Split-Path -Parent) "artifacts\hexapode_chassis\ender3_kit"
}
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
if (-not (Test-Path -LiteralPath $OpenSCAD)) {
    throw "OpenSCAD CLI not found at '$OpenSCAD'. Pass -OpenSCAD with the path to openscad.com."
}

$parts = @(
    "lower_front", "lower_center", "lower_rear",
    "upper_front", "upper_center", "upper_rear",
    "lower_joiner", "upper_joiner",
    "spacer", "us_mount", "radar_tower", "lidar_mast", "imu_pad", "gps_mast", "tof_mount"
)

foreach ($part in $parts) {
    $output = Join-Path $OutputDir "$part.stl"
    Write-Host "Exporting $part..."
    & $OpenSCAD -o $output -D "part=""$part""" $source
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $output)) {
        throw "OpenSCAD failed to export '$part' (exit $LASTEXITCODE)."
    }
}
Write-Host "STLs exported to $OutputDir"
