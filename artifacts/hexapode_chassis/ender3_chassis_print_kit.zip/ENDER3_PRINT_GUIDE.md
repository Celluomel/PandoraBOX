# Ender 3 Pro print kit

The 160 x 230 mm decks do not fit flat on a 220 x 220 mm Ender 3 Pro bed. This SCAD variant divides each deck into front, center, and rear sections at y = +/-25 mm. The longest section is about 90 mm long; each section fits flat on the bed without diagonal positioning.

## Export

Run `docs/hardware/export_ender3_kit.ps1` from PowerShell with OpenSCAD's command-line executable (`openscad.com`). For example:

```powershell
powershell -ExecutionPolicy Bypass -File .\docs\hardware\export_ender3_kit.ps1
```

The script writes separate STLs to `artifacts/hexapode_chassis/ender3_kit/`. The `light_all.stl` file is an assembled fit-check model; do not send it to the slicer as one print.

## Parts and assembly

- Print one each: `lower_front`, `lower_center`, `lower_rear`, `upper_front`, `upper_center`, `upper_rear`.
- Print six `lower_joiner` straps and six `upper_joiner` straps. Each deck has three straps at each of its two seams.
- Print the sensor parts separately. The three ultrasonic holders use three copies of `us_mount`.
- Join each seam with the straps on the underside, using M3 screws, washers, and nuts. M3 x 16 mm is a reasonable starting length for the 3.5 mm deck plus 5 mm strap and nut; confirm screw engagement and clearance before assembly.
- Reassemble the lower and upper decks with the six 55 mm spacers as in the fit-check model.

## Slicer setup and cautions

Place each plate section flat on the bed. A 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 5 top/bottom layers, and 25-35% gyroid infill are conservative prototype settings. PETG is a reasonable starting material for a chassis prototype; inspect the servo-pocket lands and splice areas before loading the robot.

This is a fit-check/prototype, not a validated load-rated chassis. The board hole coordinates and several module dimensions are still marked provisional in the SCAD source. Verify the Ventuno Q with its heatsink/fan, actual sensors, servo dimensions, cable exits, and all fastener clearances before printing the complete set. Do not mount powered servos or operate the robot until the joints and plate strength have been physically checked.
